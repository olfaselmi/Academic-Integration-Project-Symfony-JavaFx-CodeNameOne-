/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import entite.modules;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import utils.DataSource;

/**
 *
 * @author user
 */
public class ModulesService {
     private Statement ste;
    private PreparedStatement pst;
    private ResultSet rs;
   private Connection conn;

    public ModulesService() {
        conn = DataSource.getInstance().getCnx();
    }

   public void ajouterModulesPst(modules m ){
        String req = "insert into modules (nom,coeff) values (?,?)";

        try {
            pst = conn.prepareStatement(req);
            pst.setString(1, m.getNom());
            pst.setInt(2, m.getCoeff());
          pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModulesService.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    

public List <modules> readAll(String ch,String t) {
        String req = "select * from modules ";
        if(ch.length()!=0)
            req+="where nom like'"+ch+"%'";
        if(t.equals("coefficient(ordre croissant)"))
            req+="order by coeff ASC";
        else if(t.equals("coefficient(ordre decroissant)"))
            req+="order by coeff DESC";
        List <modules> list=new ArrayList<>();
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
               list.add(new modules(rs.getInt("id"), rs.getString("nom"), rs.getInt("coeff")));
           }

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
public boolean delete(int id) throws SQLException {
    
        PreparedStatement pre=conn.prepareStatement("DELETE FROM modules WHERE id="+id);
        pre.executeUpdate();
        JOptionPane.showMessageDialog(null,"module supprimé avec succées");
        return true;
    }
    
    public void modifierModules(modules m,int id) {
        String req = "update modules set nom=?, coeff=? where id=? ";

        try {
            pst = conn.prepareStatement(req);
            pst.setString(1, m.getNom());
            pst.setInt(2, m.getCoeff());
            pst.setInt(3, id);
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModulesService.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public modules getById(int id) {
        String req = "select * from modules where id='"+id+"'";
        modules e=new modules();
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
              e.setId(rs.getInt(1));
              e.setNom(rs.getString(2));
              e.setCoeff(rs.getInt(3));
           }
           
        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
      return e;  
    }
public HashMap<String,Float> stat1() {
       String req = "SELECT dom.nom,count(*) as nbr FROM domaine dom inner join demande d on d.idDomaine=dom.id inner join collaboration c on c.idDemande=d.id group by dom.nom order by nbr DESC limit 5";
        HashMap<String,Float> list=new HashMap<>();
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
              list.put(rs.getString(1),rs.getFloat(2));
           }

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
public int stat2() {
        String req = "SELECT dom.nom,count(*) as nbr FROM domaine dom inner join demande d on d.idDomaine=dom.id inner join collaboration c on c.idDemande=d.id group by dom.nom order by nbr DESC limit 5";
        int s=0;
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
              s+=rs.getInt(2);
           }

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
    }
public HashMap<String,Float> stat3() {
        String req = "select c.nom,count(*) as nbr from centre c inner join offre o on o.idCentre=c.id inner join collaboration co on co.idOffre=o.id group by c.nom order by nbr DESC LIMIT 5";
        HashMap<String,Float> list=new HashMap<>();
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
              list.put(rs.getString(1),rs.getFloat(2));
           }

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
public int stat4() {
        String req = "select c.nom,count(*) as nbr from centre c inner join offre o on o.idCentre=c.id inner join collaboration co on co.idOffre=o.id group by c.nom order by nbr DESC LIMIT 5";
        int s=0;
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
              s+=rs.getInt(2);
           }

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
    }
}
