/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import entite.Ecole;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import utils.DataSource;

/**
 *
 * @author user
 */
public class EcoleService {
     private Statement ste;
    private PreparedStatement pst;
    private ResultSet rs;

    private Connection conn;

    public EcoleService() {
        conn = DataSource.getInstance().getCnx();
    }

   public void ajouterEcolePst(Ecole e) throws SQLException{
        String req = "insert into ecole (nom,numMaison,rue,ville) values (?,?,?,?)";

        try {
            pst = conn.prepareStatement(req);
            pst.setString(1, e.getNom());
            pst.setString(2, e.getNumMaison());
            pst.setString(3, e.getRue());
            pst.setString(4, e.getVille());
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    

public List <Ecole> readAll(String ch,String t) {
        String req = "select * from ecole ";
        if(ch.length()!=0)
            req+="where nom like'"+ch+"%'";
        if(t.equals("Ville(ordre croissant)"))
            req+="order by ville ASC";
        else if(t.equals("Ville(ordre decroissant)"))
            req+="order by ville DESC";
        List <Ecole> list=new ArrayList<>();
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
               list.add(new Ecole(rs.getInt("id"), rs.getString("nom"), rs.getString("numMaison"), rs.getString("rue"), rs.getString("ville")));
           }

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
public void supprimerEcole(int id) {
        String req = "delete from ecole where id=? ";

        try {
            pst = conn.prepareStatement(req);
            pst.setInt(1, id);
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public void modifierEcole(Ecole e,int id) {
        String req = "update ecole set nom=?, numMaison=?,rue=?,ville=? where id=? ";

        try {
            pst = conn.prepareStatement(req);
            pst.setString(1, e.getNom());
            pst.setString(2, e.getNumMaison());
            pst.setString(3, e.getRue());
            pst.setString(4, e.getVille());
            pst.setInt(5, id);
            pst.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public Ecole getById(int id) {
        String req = "select * from ecole where id='"+id+"'";
        Ecole e=new Ecole();
        try {
            ste = conn.createStatement();
           rs= ste.executeQuery(req);
           while(rs.next()){
              e.setId(rs.getInt(1));
              e.setNom(rs.getString(2));
              e.setNumMaison(rs.getString(3));
              e.setRue(rs.getString(4));
              e.setVille(rs.getString(5));
           }
           
        } catch (SQLException ex) {
            Logger.getLogger(EcoleService.class.getName()).log(Level.SEVERE, null, ex);
        }
      return e;  
    }

}
