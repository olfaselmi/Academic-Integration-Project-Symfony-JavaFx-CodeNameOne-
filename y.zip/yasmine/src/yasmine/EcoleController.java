/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yasmine;

import Service.EcoleService;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfWriter;
import entite.Ecole;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class EcoleController implements Initializable {

    @FXML
    private Label nom;
    @FXML
    private Label nbnotif;
    @FXML
    private Button buttonHome;
    @FXML
    private Button buttonEcole;
    @FXML
    private Button buttonModule;
    @FXML
    private Button goodsbtn;
    @FXML
    private Label userN;
    @FXML
    private ScrollPane listE;
    @FXML
    private Hyperlink link;
    @FXML
    private Label id;
    @FXML
    private TextField nomE;
    @FXML
    private TextField numL;
    @FXML
    private TextField nomR;
    @FXML
    private TextField ville;
    @FXML
    private Button btnAjout;
    @FXML
    private Button btnModif;
    @FXML
    private TextField rech;
    @FXML
    private VBox vb;
    private EcoleService es=new EcoleService();
    private Ecole e=new Ecole();
    private String ch="";
    private String t="";
    @FXML
    private ChoiceBox<String> trie;
    @FXML
    private AnchorPane anchor;
    @FXML
    private Button imprim;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnModif.setDisable(true);
        btnAjout.setDisable(false);
        trie.setValue("-");
        trie.getItems().add("-");
        trie.getItems().add("Ville(ordre croissant)");
        trie.getItems().add("Ville(ordre decroissant)");
        trie.setOnAction(this::change);
        releaseChoice(vb);
        makeList();
    }    
public void change(ActionEvent a){
       t=trie.getValue();
       makeList();
   }
    @FXML
    private void changeScreenHome(ActionEvent event) throws IOException {
        FXMLLoader l=new FXMLLoader(getClass().getResource("EspaceAdmin.fxml"));
        Parent tableViewParent = l.load();
        EspaceAdminController hc=l.getController();
        hc.showInformation(userN.getText());
        Scene tableViewScene = new Scene(tableViewParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    private void changeScreenEcole(ActionEvent event) throws IOException {
        FXMLLoader l=new FXMLLoader(getClass().getResource("ecole.fxml"));
        Parent tableViewParent = l.load();
        EcoleController hc=l.getController();
        hc.showInformation(userN.getText());
        Scene tableViewScene = new Scene(tableViewParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
    }
    

    @FXML
    private void changeScreenModule(ActionEvent event) {
    }

    @FXML
    private void ajouter(ActionEvent event) {
        if(controle()==true){
        try {
            es.ajouterEcolePst(new Ecole(0,nomE.getText(),numL.getText(),nomR.getText(),ville.getText()));
            init();
            makeList();
        } catch (SQLException ex) {
            Logger.getLogger(EcoleController.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }

    @FXML
    private void modif(ActionEvent event) {
        if(controle()==true){
        es.modifierEcole(new Ecole(0,nomE.getText(),numL.getText(),nomR.getText(),ville.getText()),e.getId());  
        makeList();
        btnModif.setDisable(true);
        btnAjout.setDisable(false);
        init();}
    }

    @FXML
    private void chercher(ActionEvent event) {
        ch=rech.getText();
        makeList();
    }

    public void showInformation(String n)
    {
        userN.setText(n);
    }
    public void makeList()
    {List <Ecole> list=es.readAll(ch,t);
    vb=new VBox();
    for (int i = 0; i < list.size(); i++){
        HBox h=new HBox();
        h.setPrefHeight(66);
        h.setPrefWidth(441);
        h.setId("ligneDemande");
        VBox v=new VBox();
        Label l1=new Label();
        l1.setText("Ecole "+list.get(i).getNom());
        l1.setPrefWidth(85);
        l1.setPrefHeight(78);
        l1.setFont(Font.font("System", 14));
        l1.setId("l1");
        l1.setTextAlignment(TextAlignment.CENTER);
        Label l2=new Label();
        l2.setText(list.get(i).getNumMaison()+" Rue "+list.get(i).getRue()+" "+list.get(i).getVille());
        l2.setPrefWidth(205);
        l2.setPrefHeight(78);
        l2.setId("l2");
        l2.setFont(Font.font("System", 14));
        l2.setTextAlignment(TextAlignment.CENTER);
         Label l3=new Label();
        l3.setText(String.valueOf(list.get(i).getId()));
        l3.setPrefWidth(15);
        l3.setPrefHeight(17);
        l3.setVisible(false);
        Hyperlink btn=new Hyperlink();
        btn.setText("Supprimer");
        btn.setPrefHeight(66);
        btn.setPrefWidth(95);
        btn.setOnAction(a->{
              e.setId(Integer.parseInt(l3.getText()));
              supprimer();
                  });
        Hyperlink hl=new Hyperlink();
        hl.setText(">>>");
        hl.setPrefHeight(66);
        hl.setPrefWidth(49);
        hl.setOnAction(a->{
              e.setId(Integer.parseInt(l3.getText()));
              releaseChoice(vb);
              h.setStyle("-fx-background-color : #34669a;");
              modifier();
                  });
        
        h.setOnMouseClicked(ev->{
        btnModif.setDisable(true);
        btnAjout.setDisable(false);
        releaseChoice(vb);
        h.setStyle("-fx-background-color : #34669a;");
        e.setId(Integer.valueOf(l3.getText()));
        });       
        h.getChildren().addAll(l1,l2,btn,hl,l3);
        vb.getChildren().addAll(h);
    }
     listE.setContent(vb);
    }

    private void supprimer() {
        es.supprimerEcole(e.getId());
        makeList();
    }
    private void releaseChoice(VBox v) {
    for (int j = 0; j < v.getChildren().size(); j++)
            v.getChildren().get(j).setStyle("-fx-background-color :#e6e6e6;");
    }

    private void modifier() {
        btnModif.setDisable(false);
        btnAjout.setDisable(true);
        e=es.getById(e.getId());
        nomE.setText(e.getNom());
        numL.setText(e.getNumMaison());
        nomR.setText(e.getRue());
        ville.setText(e.getVille());
    }
    private void init() {
        nomE.setText("");
        numL.setText("");
        nomR.setText("");
        ville.setText("");
    }
     private void imprimer() throws FileNotFoundException {
     Document doc=new Document();
     FileChooser fc=new FileChooser();
     fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF File","*.pdf"));
     fc.setTitle("save contract");
     fc.setInitialFileName("untitled.pdf");
     Stage stage=(Stage) anchor.getScene().getWindow();
     File file=fc.showSaveDialog(stage);
     if(file!=null){
         String str=file.getAbsolutePath();
        try {com.itextpdf.text.Font blueFont = FontFactory.getFont(FontFactory.HELVETICA, 16, com.itextpdf.text.Font.NORMAL, new CMYKColor(255, 0, 0, 0));
        com.itextpdf.text.Font blackFont = FontFactory.getFont(FontFactory.HELVETICA, 9, com.itextpdf.text.Font.NORMAL, new CMYKColor(255, 255, 255, 255));
            PdfWriter.getInstance(doc, new FileOutputStream(str));
            doc.open();
            Paragraph p=new Paragraph("                                                   Liste D Ecoles",blueFont);
            doc.add(p);
            
            Paragraph contenu = new Paragraph(preparerMsg(), blackFont);
            doc.add(contenu);
            doc.close();
        } catch (DocumentException ex) {
            Logger.getLogger(EcoleController.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }
    private String preparerMsg() {
       String ch="\n \n \n \n \n";
       List <Ecole> list=es.readAll("","");
   
    for (int i = 0; i < list.size(); i++){
        ch+=String.valueOf(i+1)+"- Ecole: "+list.get(i).getNom()+"        Adresse: "+list.get(i).getNumMaison()+" "+list.get(i).getRue()+" "+list.get(i).getVille()+"\n \n";
}
    return ch;
    }

    @FXML
    private void imprim(ActionEvent event) {
        try {
            imprimer();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EcoleController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public boolean controle()
    {boolean test=true;
        if(nomE.equals("")){
           test=false;
           JOptionPane.showMessageDialog(null,"le nom d ecole est obligatoire");
        }
        if((numL.equals(""))||(chaineNum(numL.getText())==false)){
           test=false;
           numL.setText("");
           JOptionPane.showMessageDialog(null,"coefficient doit etre un numero");
        }
        if(nomR.equals("")){
           test=false;
           JOptionPane.showMessageDialog(null,"le nom de Rue est obligatoire");
        }
        if(ville.equals("")){
           test=false;
           JOptionPane.showMessageDialog(null,"le nom de ville est obligatoire");
        }
      return test;      
    }
    private boolean chaineNum(String ch){
    return ch.matches("[+-]?\\d*(\\.\\d+)?");
}
}
