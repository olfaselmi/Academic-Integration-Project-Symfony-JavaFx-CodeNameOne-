/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yasmine;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class EspaceAdminController implements Initializable {

    @FXML
    private Label nom;
    @FXML
    private Label nbnotif;
    @FXML
    private Button buttonHome;
    @FXML
    private Button goodsbtn;
    @FXML
    private Label userN;
    @FXML
    private Button buttonEcole;
    @FXML
    private Button buttonModule;
    @FXML
    private Button btnStat;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void changeScreenHome(ActionEvent event) throws IOException {
        FXMLLoader l=new FXMLLoader(getClass().getResource("EspaceAdmin.fxml"));
        Parent tableViewParent = l.load();
        EspaceAdminController hc=l.getController();
        hc.showInformation("41");
        Scene tableViewScene = new Scene(tableViewParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    private void changeScreenEcole(ActionEvent event) throws IOException {
        FXMLLoader l=new FXMLLoader(getClass().getResource("ecole.fxml"));
        Parent tableViewParent = l.load();
        EcoleController hc=l.getController();
        hc.showInformation("41");
        Scene tableViewScene = new Scene(tableViewParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    private void changeScreenModule(ActionEvent event) throws IOException {
        FXMLLoader l=new FXMLLoader(getClass().getResource("module.fxml"));
        Parent tableViewParent = l.load();
        ModuleController hc=l.getController();
        hc.showInformation("41");
        Scene tableViewScene = new Scene(tableViewParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
    }
    public void showInformation(String n)
    {
        userN.setText(n);
    }

    @FXML
    private void changeStat(ActionEvent event) throws IOException {
        FXMLLoader l=new FXMLLoader(getClass().getResource("Stats.fxml"));
        Parent tableViewParent = l.load();
        StatsController hc=l.getController();
        hc.showInformation("41");
        Scene tableViewScene = new Scene(tableViewParent);
        
        //This line gets the Stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(tableViewScene);
        window.show();
    }
    
}
