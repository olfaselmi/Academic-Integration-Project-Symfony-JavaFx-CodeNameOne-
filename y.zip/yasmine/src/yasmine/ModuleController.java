/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yasmine;

import Service.ModulesService;
import entite.modules;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ModuleController implements Initializable {

    @FXML
    private Label nom;
    @FXML
    private Label nbnotif;
    @FXML
    private Button buttonHome;
    @FXML
    private Button buttonEcole;
    @FXML
    private Button buttonModule;
    @FXML
    private Button goodsbtn;
    @FXML
    private Label userN;
    @FXML
    private ScrollPane listE;
    @FXML
    private VBox vb;
    @FXML
    private Hyperlink link;
    @FXML
    private Label id;
    @FXML
    private TextField nomM;
    @FXML
    private TextField coeff;
    @FXML
    private Button btnAjout;
    @FXML
    private Button btnModif;
    @FXML
    private TextField rech;
    @FXML
    private ChoiceBox<String> trie;
    private String t="";
    private String ch="";
    private ModulesService ms=new ModulesService();
    private modules m=new modules();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        trie.setValue("-");
        trie.getItems().add("-");
        trie.getItems().add("Ville(ordre croissant)");
        trie.getItems().add("Ville(ordre decroissant)");
        trie.setOnAction(this::change);
    }    
public void change(ActionEvent a){
       t=trie.getValue();
       makeList();
   }
    @FXML
    private void changeScreenHome(ActionEvent event) {
    }

    @FXML
    private void changeScreenEcole(ActionEvent event) {
    }

    @FXML
    private void changeScreenModule(ActionEvent event) {
    }

    @FXML
    private void ajouter(ActionEvent event) {
        if(controle()==true){
        ms.ajouterModulesPst(new modules(nomM.getText(),Integer.valueOf(coeff.getText())));
        init();
        makeList();}
    }

    @FXML
    private void modif(ActionEvent event) {
        if(controle()==true){
        ms.modifierModules(new modules(nomM.getText(),Integer.valueOf(coeff.getText())), m.getId());  
        makeList();
        btnModif.setDisable(true);
        btnAjout.setDisable(false);
        init();}
    }

    @FXML
    private void chercher(ActionEvent event) {
        ch=rech.getText();
        makeList();
    }

    private void makeList() {
        List <modules> list=ms.readAll(ch,t);
    vb=new VBox();
    for (int i = 0; i < list.size(); i++){
        HBox h=new HBox();
        h.setPrefHeight(66);
        h.setPrefWidth(441);
        h.setId("ligneDemande");
        VBox v=new VBox();
        Label l1=new Label();
        l1.setText("Nom Module "+list.get(i).getNom());
        l1.setPrefWidth(167);
        l1.setPrefHeight(66);
        l1.setFont(Font.font("System", 14));
        l1.setId("l1");
        l1.setTextAlignment(TextAlignment.CENTER);
        Label l2=new Label();
        l2.setText("Coefficient: "+String.valueOf(list.get(i).getCoeff()));
        l2.setPrefWidth(122);
        l2.setPrefHeight(66);
        l2.setId("l2");
        l2.setFont(Font.font("System", 14));
        l2.setTextAlignment(TextAlignment.CENTER);
         Label l3=new Label();
        l3.setText(String.valueOf(list.get(i).getId()));
        l3.setPrefWidth(15);
        l3.setPrefHeight(17);
        l3.setVisible(false);
        Hyperlink btn=new Hyperlink();
        btn.setText("Supprimer");
        btn.setPrefHeight(66);
        btn.setPrefWidth(107);
        btn.setOnAction(a->{
              m.setId(Integer.parseInt(l3.getText()));
              supprimer();
                  });
        Hyperlink hl=new Hyperlink();
        hl.setText(">>>");
        hl.setPrefHeight(66);
        hl.setPrefWidth(49);
        hl.setOnAction(a->{
              m.setId(Integer.parseInt(l3.getText()));
              releaseChoice(vb);
              h.setStyle("-fx-background-color : #34669a;");
              modifier();
                  });
        
        h.setOnMouseClicked(ev->{
        btnModif.setDisable(true);
        btnAjout.setDisable(false);
        releaseChoice(vb);
        h.setStyle("-fx-background-color : #34669a;");
        m.setId(Integer.valueOf(l3.getText()));
        });       
        h.getChildren().addAll(l1,l2,btn,hl,l3);
        vb.getChildren().addAll(h);
    }
     listE.setContent(vb);
    }

    private void supprimer()  {
        try {
            ms.delete(m.getId());
        } catch (SQLException ex) {
            Logger.getLogger(ModuleController.class.getName()).log(Level.SEVERE, null, ex);
        }
        makeList();  
    }
    private void releaseChoice(VBox v) {
    for (int j = 0; j < v.getChildren().size(); j++)
            v.getChildren().get(j).setStyle("-fx-background-color :#e6e6e6;");
    }

    private void modifier() {
        btnModif.setDisable(false);
        btnAjout.setDisable(true);
        m=ms.getById(m.getId());
        nomM.setText(m.getNom());
        coeff.setText(String.valueOf(m.getCoeff()));
    }
    private void init() {
         nomM.setText("");
        coeff.setText("");
    }
    public void showInformation(String n)
    {
        userN.setText(n);
    }
    public boolean controle()
    {boolean test=true;
        if(nomM.equals("")){
           test=false;
           JOptionPane.showMessageDialog(null,"le nom du module est obligatoire");
        }
        if((coeff.equals(""))||(chaineNum(coeff.getText())==false)){
           test=false;
           coeff.setText("");
           JOptionPane.showMessageDialog(null,"coefficient doit etre un numero");
        }
      return test;      
    }
    private boolean chaineNum(String ch){
    return ch.matches("[+-]?\\d*(\\.\\d+)?");
}
}
