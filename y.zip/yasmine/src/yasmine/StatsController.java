/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yasmine;

import Service.ModulesService;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author user
 */
public class StatsController implements Initializable {

    @FXML
    private Label nom;
    @FXML
    private Label nbnotif;
    @FXML
    private Button buttonHome;
    @FXML
    private Button buttonEcole;
    @FXML
    private Button buttonModule;
    @FXML
    private Button goodsbtn;
    @FXML
    private Label userN;
    @FXML
    private BarChart<?, ?> chart;
    @FXML
    private NumberAxis y;
    @FXML
    private CategoryAxis x;
    private ModulesService ms=new ModulesService();
    @FXML
    private PieChart pie;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       getPourcentageChart();
       getPourcentageChart2();
    }    

    @FXML
    private void changeScreenHome(ActionEvent event) {
    }

    @FXML
    private void changeScreenEcole(ActionEvent event) {
    }

    @FXML
    private void changeScreenModule(ActionEvent event) {
    }
    private void getPourcentageChart(){
        XYChart.Series set1= new XYChart.Series<>();
        HashMap<String,Float> map=ms.stat3();
        int s=ms.stat4();
        for (Map.Entry mapentry : map.entrySet()) {
          float x=(float)mapentry.getValue()*100/s;
           set1.getData().add(new XYChart.Data(mapentry.getKey(),x));
        }
        chart.getData().addAll(set1);
        
    }
     public void showInformation(String n)
    {
        userN.setText(n);
    }
     private void getPourcentageChart2(){
        ObservableList<PieChart.Data> list=FXCollections.observableArrayList();
        HashMap<String,Float> map=ms.stat1();
        int s=ms.stat2();
        for (Map.Entry mapentry : map.entrySet()) {
          float x=(float)mapentry.getValue()*100/s;
           list.add(new PieChart.Data((String)mapentry.getKey(), x));
        }
        pie.setData(list);
        
    }
}
