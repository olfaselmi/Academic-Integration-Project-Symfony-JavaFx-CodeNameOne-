-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 01 avr. 2021 à 14:34
-- Version du serveur :  5.7.31
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `swr`
--

-- --------------------------------------------------------

--
-- Structure de la table `centre`
--

DROP TABLE IF EXISTS `centre`;
CREATE TABLE IF NOT EXISTS `centre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) DEFAULT NULL,
  `numMaison` varchar(20) DEFAULT NULL,
  `rue` varchar(35) DEFAULT NULL,
  `ville` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `centre`
--

INSERT INTO `centre` (`id`, `nom`, `numMaison`, `rue`, `ville`) VALUES
(3, 'a', 'b', 'c', 'a'),
(2, 'a', 'b', 'c', 'd');

-- --------------------------------------------------------

--
-- Structure de la table `collaboration`
--

DROP TABLE IF EXISTS `collaboration`;
CREATE TABLE IF NOT EXISTS `collaboration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idDemande` int(11) NOT NULL,
  `idOffre` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idDemande` (`idDemande`),
  KEY `idOffre` (`idOffre`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `collaboration`
--

INSERT INTO `collaboration` (`id`, `idDemande`, `idOffre`) VALUES
(20, 36, 55);

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

DROP TABLE IF EXISTS `cours`;
CREATE TABLE IF NOT EXISTS `cours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `contenu` text NOT NULL,
  `dateD` date NOT NULL,
  `dateF` date NOT NULL,
  `placeDispo` varchar(25) NOT NULL,
  `idEnseig` int(11) NOT NULL,
  `emploi` int(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cours`
--

INSERT INTO `cours` (`id`, `titre`, `contenu`, `dateD`, `dateF`, `placeDispo`, `idEnseig`, `emploi`) VALUES
(4, 'test', 'test', '2021-03-19', '2021-03-26', '5', 2, NULL),
(6, 'mm', 'dddd', '2021-03-19', '2021-03-25', '6', 2, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `demande`
--

DROP TABLE IF EXISTS `demande`;
CREATE TABLE IF NOT EXISTS `demande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateDebut` date NOT NULL,
  `DateFin` date NOT NULL,
  `resultat` varchar(20) NOT NULL DEFAULT 'en attente',
  `idDomaine` int(11) DEFAULT NULL,
  `montantPropose` bigint(20) NOT NULL,
  `idEcole` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idDomaine` (`idDomaine`),
  KEY `idEcole` (`idEcole`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demande`
--

INSERT INTO `demande` (`id`, `dateDebut`, `DateFin`, `resultat`, `idDomaine`, `montantPropose`, `idEcole`) VALUES
(29, '2021-03-24', '2021-04-09', 'signe', 3, 300, 2),
(32, '2021-03-29', '2021-04-01', 'signe', 3, 230, 2),
(36, '2021-03-30', '2021-04-01', 'signe', 3, 130, 2),
(37, '2021-03-31', '2021-04-09', 'en attente', 4, 2000, 2),
(38, '2021-03-31', '2021-04-09', 'en attente', 3, 3000, 2);

-- --------------------------------------------------------

--
-- Structure de la table `discussion`
--

DROP TABLE IF EXISTS `discussion`;
CREATE TABLE IF NOT EXISTS `discussion` (
  `idd` int(11) NOT NULL AUTO_INCREMENT,
  `mail_source` varchar(50) NOT NULL,
  `mail_dest` varchar(50) NOT NULL,
  `titre` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `dateenv` varchar(25) NOT NULL,
  PRIMARY KEY (`idd`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `discussion`
--

INSERT INTO `discussion` (`idd`, `mail_source`, `mail_dest`, `titre`, `message`, `dateenv`) VALUES
(2, 'etud@', 'azer.jomni@esprit.tn', 'math', 'merci', '2021-03-10 23:55:28'),
(9, 'azer.jomni@esprit.tn', 'form@form.tn', 'Offre de stage', 'Bonsoir,\r\nj\'espère que vous allez bien .\r\n\r\nEn effet    vous propose  un stage en Design Graphique & Audiovisuel  est une plateforme communautaire spécialisée dans l’univers ', '2021-03-11 13:07:12'),
(8, 'etud@', 'form@', 'cour', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '2021-03-11 13:07:00'),
(5, 'Etudiant : et', '@aaaa', 'aaa', 'aaaa', '2021-03-11 10:32:07'),
(6, 'etud@', 'esprit', 'aaa', 'bonjour', '2021-03-11 10:41:56'),
(7, 'etud@', 'respe@', 'ok', 'ok', '2021-03-11 11:06:38'),
(10, 'etud@', 'form@', 'math', 'merci', '2021-03-12 13:23:44'),
(11, 'etud@', 'form@', 'math', 'merci', '2021-03-12 13:29:51'),
(12, 'etud@', 'form@', 'math', 'merci', '2021-03-12 16:36:15'),
(13, 'azer.jomni@esprit.tn', 'azer@', 'aa', 'aaaaa', '2021-03-19 00:04:57'),
(18, 'form@form.tn', 'azer.jomni@esprit.tn', 'Offre de stage', 'Bien recu merci beaucoup ', '2021-03-24 15:40:44'),
(15, 'form@form.tn', 'etud@', 'Accepter', 'merci', '2021-03-23 22:47:09'),
(16, 'respe@respe.tn', 'form@form.tn', 'Unity club', '\r\nHi azer,\r\n \r\nUnity 2020 LTS (Long-term Support) is now available, and we’ve updated all of our Microgames to run on this latest version. Are you ready to make a 2D game? Make sure to get our tips on setting up a 2D project the smart way. And some of our favorite YouTubers have fun with recreating popular titles. Have fun and happy creating!', '2021-03-29 12:47:09'),
(17, 'etud@etud.tn', 'form@form.tn', 'Cours de Math', 'Bonjour Mr esque vous pouver m\'envoyer le cour de derivabilté', '2021-01-23 00:47:09'),
(19, 'form@form.tn', 'respe@respe.tn', 'Offre de stage', 'Bien recu merci beaucoup ', '2021-03-24 22:23:10'),
(20, 'ahmed@ahmedd.tn', 'form@form.tn', 'Takwira', 'Bonjour Mr/Mme <form> ghodwa', '2021-03-25 13:51:23');

-- --------------------------------------------------------

--
-- Structure de la table `domaine`
--

DROP TABLE IF EXISTS `domaine`;
CREATE TABLE IF NOT EXISTS `domaine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `domaine`
--

INSERT INTO `domaine` (`id`, `nom`) VALUES
(3, 'web'),
(4, 'Data Science');

-- --------------------------------------------------------

--
-- Structure de la table `ecole`
--

DROP TABLE IF EXISTS `ecole`;
CREATE TABLE IF NOT EXISTS `ecole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) DEFAULT NULL,
  `numMaison` varchar(20) DEFAULT NULL,
  `rue` varchar(35) DEFAULT NULL,
  `ville` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `ecole`
--

INSERT INTO `ecole` (`id`, `nom`, `numMaison`, `rue`, `ville`) VALUES
(8, 'iset', '44', 'tunis', 'tunis'),
(2, 'esprit', '34', 'ghazela', 'ariana'),
(7, 'centrale', '55', 'tunis', 'tunis');

-- --------------------------------------------------------

--
-- Structure de la table `enseignant`
--

DROP TABLE IF EXISTS `enseignant`;
CREATE TABLE IF NOT EXISTS `enseignant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `salaire` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idUser` (`idUser`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `enseignant`
--

INSERT INTO `enseignant` (`id`, `idUser`, `salaire`) VALUES
(1, 13, 323),
(4, 49, 437.5),
(2, 5, 665);

-- --------------------------------------------------------

--
-- Structure de la table `formateur`
--

DROP TABLE IF EXISTS `formateur`;
CREATE TABLE IF NOT EXISTS `formateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `salaire` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idUser` (`idUser`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `formateur`
--

INSERT INTO `formateur` (`id`, `idUser`, `salaire`) VALUES
(1, 19, 421),
(8, 45, 0),
(4, 50, 297),
(5, 57, 660),
(6, 58, 513),
(7, 59, 598),
(9, 61, 807),
(25, 5, 525),
(2, 6, 525);

-- --------------------------------------------------------

--
-- Structure de la table `formation`
--

DROP TABLE IF EXISTS `formation`;
CREATE TABLE IF NOT EXISTS `formation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) DEFAULT NULL,
  `image` varchar(250) NOT NULL,
  `contenu` text NOT NULL,
  `placeDispo` varchar(25) NOT NULL,
  `idFormateur` int(11) NOT NULL,
  `emploi` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `formation`
--

INSERT INTO `formation` (`id`, `titre`, `image`, `contenu`, `placeDispo`, `idFormateur`, `emploi`) VALUES
(12, 'formation 2', 'img1.jpg', 'Designed by English experts, our online English classes and courses provide a safe, inclusive learning community. Our highly qualified teachers help learners improve their English speaking, listening, reading and writing skills online, build their confidence and achieve their goals.', '5', 2, NULL),
(14, 'formation 3', 'img3.jpg', 'Dans son livre « Apprendre… oui mais comment » (ESF 1987), Philippe Meirieu parle « d’identifier les notions noyaux qui représentent un progrès décisif dans la progression de l’élève ». En d’autres termes, au regard des objectifs pédagogiques visés, du public (ses pré-acquis, ses besoins) et du format de la formation (module e-learning de 30mn ? présentiel de 2 jours ?) dégager les concepts clés', '22', 25, NULL),
(15, 'aaaaaaa', '1280px-Flag_of_Tunisia.svg.png', 'aaaaaaaa', '12', 4, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(40) NOT NULL,
  `coeff` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `modules`
--

INSERT INTO `modules` (`id`, `nom`, `coeff`) VALUES
(1, 'anglais', 5),
(5, 'francais', 4);

-- --------------------------------------------------------

--
-- Structure de la table `offre`
--

DROP TABLE IF EXISTS `offre`;
CREATE TABLE IF NOT EXISTS `offre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prixPropose` int(11) NOT NULL,
  `certifie` tinyint(1) NOT NULL,
  `idCentre` int(11) NOT NULL,
  `idDemande` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idCentre` (`idCentre`),
  KEY `idDemande` (`idDemande`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `offre`
--

INSERT INTO `offre` (`id`, `prixPropose`, `certifie`, `idCentre`, `idDemande`) VALUES
(55, 4000, 1, 2, 36);

-- --------------------------------------------------------

--
-- Structure de la table `respecole`
--

DROP TABLE IF EXISTS `respecole`;
CREATE TABLE IF NOT EXISTS `respecole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `idEcole` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idUser` (`idUser`),
  KEY `idEcole` (`idEcole`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `respecole`
--

INSERT INTO `respecole` (`id`, `idUser`, `idEcole`) VALUES
(1, 1, 1),
(9, 12, 2),
(10, 14, 2),
(11, 18, 2),
(13, 52, 2);

-- --------------------------------------------------------

--
-- Structure de la table `respentre`
--

DROP TABLE IF EXISTS `respentre`;
CREATE TABLE IF NOT EXISTS `respentre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `idCentre` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idUser` (`idUser`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `respentre`
--

INSERT INTO `respentre` (`id`, `idUser`, `idCentre`) VALUES
(1, 44, 2);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `idu` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tel` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `usernameCanonical` varchar(30) DEFAULT NULL,
  `emailCanonical` varchar(30) DEFAULT NULL,
  `enabled` int(11) NOT NULL DEFAULT '0',
  `salt` varchar(30) DEFAULT NULL,
  `lastlogin` date DEFAULT NULL,
  `confirmationToken` varchar(30) DEFAULT NULL,
  `passwordrequestedat` varchar(30) DEFAULT NULL,
  `roles` varchar(30) NOT NULL,
  `dateins` date NOT NULL,
  `radom` varchar(255) NOT NULL,
  `iteration` int(30) NOT NULL DEFAULT '3',
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`idu`),
  UNIQUE KEY `mail` (`email`),
  UNIQUE KEY `tel` (`tel`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `usernameCanonical` (`usernameCanonical`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`idu`, `nom`, `prenom`, `country`, `email`, `password`, `tel`, `username`, `usernameCanonical`, `emailCanonical`, `enabled`, `salt`, `lastlogin`, `confirmationToken`, `passwordrequestedat`, `roles`, `dateins`, `radom`, `iteration`, `image`) VALUES
(53, 'wajj', 'wajj', 'algerie', 'wajdi@eee.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 55191999, 'wajj', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-20', '319950', 3, 'C:\\Users\\u\\Desktop\\37914554_2165660807009911_3831861966272462848_o (1).jpg'),
(41, 'kamel', 'chourou', 'tunisie', 'admin@admin.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 21287713, 'chourou', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'admin', '2020-02-23', '397817', 3, 'f_5e52f37ec7d29.png'),
(40, 'chahro', 'kakda', 'Morroco', 'mohamedamine@esprit.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeC6jJgPBE9uvsDb3XoJ24ujnPWNTPiie', 58247634, 'amine98', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2020-02-23', '303236', 3, 'f_5e52ceabecece.png'),
(42, 'dahdauda', 'daudabud', 'dahduazd', 'dhaidhaid@dada.com', '$2a$10$OYty/sJuxGPcgxtIKQHiWeKx1du1mVOLHJTAdBGPj8K9Bvw3j3TZG', 98745632, 'dahuadha85', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2020-02-24', '214690', 3, 'f_5e53b3fd0baae.png'),
(43, 'soulah', 'souuu', 'Tunisia', 'salahbenhamida@yahoo.fr', '$2a$10$OYty/sJuxGPcgxtIKQHiWeFHjilf23H13szZDSreMJlFPFC4M657.', 55879568, 'benhamida96', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2020-02-24', '275928', 3, 'f_5e5401785e89d.jpg'),
(44, 'jomni', 'azer', 'tunisie', 'ilyes.bensaid@esprit.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 55191991, 'ilyes.bensaid@esprit.tn', NULL, NULL, 1, NULL, NULL, NULL, NULL, 'Responsable Centre', '2021-03-17', '315245', 3, '268265.png'),
(46, 'aaaaaaaa', 'aaaaaaaaa', 'aaaaaaaa', 'aaaa.aaaaaa@esprit.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWe2W3HpJ.9sdUqQAb4BSUn8gZjz2N8MUu', 55555555, 'aaaaaaaa', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-17', '278201', 3, ''),
(47, 'sana', 'ben fadhel', 'tunisie', 'etud@etud.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 12522, 'etud', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-18', '351346', 3, 'etud.png'),
(48, 'azerr', 'azerr', 'tun', 'azer.jomni@gmail.com', '$2a$10$OYty/sJuxGPcgxtIKQHiWe6U.s.lHmQex8N4Kpgq3NCl.AHduGpz.', 55555554, 'azerr', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-18', '262198', 3, ''),
(5, 'azer', 'jomni', 'tunisie', 'azer@form.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 12365410, 'fAzer', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Enseignant', '2021-03-19', '353316', 3, '.png'),
(50, 'form', 'form', 'tunisie', 'form@form.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 55191997, 'form', NULL, NULL, 1, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-19', '202899', 3, '.png'),
(51, 'enss', 'enss', 'tunisie', 'ens@ens.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 22331144, 'enss', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Enseignant', '2021-03-19', '305890', 3, '.png'),
(52, 'respe', 'respe', 'tunisie', 'respe@respe.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 44556633, 'respe', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Responsable Ecole', '2021-03-19', '264222', 3, '.png'),
(54, 'yyyy', 'yyyy', 'tunisie', 'youssef@eee.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 55448877, 'yousseff', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-20', '334010', 3, 'C:\\Users\\u\\Desktop\\37914554_2165660807009911_3831861966272462848_o (1).jpg'),
(55, 'nabil', 'nabil', 'hliff', 'nabil@kouki.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 22448877, 'nabil12', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Enseignant', '2021-03-24', '268494', 3, 'nabil12.png'),
(56, 'ridhaa', 'riadhaa', 'ttttttt', 'ridha@esprit.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 66339988, 'radhwen', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Responsable Centre', '2021-03-24', '252109', 3, ''),
(1, 'ahmed', 'ahmed', 'tunisie', 'ahmed@ahmedd.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 92702534, 'ahmedd', NULL, NULL, 1, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-25', '214950', 3, 'ahmedd.png'),
(6, 'ahmed', 'ahmed', 'ezzahra', 'ahmed@ahmed.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 92702533, 'ahmed1920', NULL, NULL, 1, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-25', '354633', 3, ''),
(13, 'hassen', 'hassen', 'tunisie', 'hassen@esprit.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 33447788, 'hsouna', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Enseignant', '2021-03-26', '247644', 3, 'hsouna.png'),
(2, 'aziz', 'aziz', 'ezzahra', 'aziz@aziz.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 27758735, 'aziz07', NULL, NULL, 1, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-26', '208258', 3, 'aziz07.png'),
(62, 'educ', 'educ', 'ezzahra', 'educ@educ.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 10203040, 'educ', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-26', '219812', 3, 'educ.png'),
(63, 'eduu', 'eduu', 'aaaaa', 'eduu@eduu.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 44552200, 'eduu', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-26', '384731', 3, 'eduu.png'),
(64, 'aaaaaa', 'aaaaaaaa', 'aaaaaaaaaa', 'hasn@has.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeu8Nf8wjVXtaFkap4qO1Tzmf76PZI5.G', 22001144, 'haaaa', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-26', '387036', 3, 'haaaa.png'),
(65, 'aaaaaaaaa', 'aaaaaa', 'aaaaaaa', 'aaaa@aaaa.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeA0SX76dUP7jQImshvzn.10whmUhFBnq', 88441133, 'aaaa', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-26', '300375', 3, 'default.png'),
(66, 'qqqqqqqq', 'qqqqqq', 'qqqqqqqq', 'aaasa@aaaa.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeI.p1Z2bEXktVG/UEbZ3QzdL/pEmb0Ya', 77446633, 'qqqqqqq', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-26', '371336', 3, 'default.png'),
(67, 'ssssssss', 'sssssssss', 'ssssss', 'sssss@ssssssss.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeKuz4JEUa6PzVe7hpjdd0XdJpVcVl3Ra', 119988, 'ssssssssss', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'user', '2021-03-26', '331274', 3, 'default.png'),
(68, 'rrrrrrrrrr', 'rrrrrrrrrrrr', 'rrrrrrrrr', 'rrrrrrrr@rrrrrrrrrr.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWebpL0oD8FazleqdnQaYtV/Y3KoBUgTN2', 10234780, 'rrrrrrrrr', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Enseignant', '2021-03-26', '317027', 3, 'rrrrrrrrr.png'),
(70, 'hassine', 'lakhal', 'tunisia', 'Lakhalhassine3@gmail.com', '$2a$10$OYty/sJuxGPcgxtIKQHiWeWWaOF6DMb8ah8PNscIvoMjQmSU97m9i', 94448384, 'hassine', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Responsable Ecole', '2021-03-27', '243232', 3, 'hassine.png'),
(71, 'aaaaaaa', 'aaaaaaa', 'aaaaa', 'aaaa@aaaaaaa.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeviLraoBlEt5ghFELHyeQy4hY8.j3NMu', 11447788, 'azer19199999', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-27', '298030', 3, 'azer19199999.png'),
(72, 'aaaaaaa', 'aaaaaaa', 'aaaaa', 'aaaa@aaaaaa.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeviLraoBlEt5ghFELHyeQy4hY8.j3NMu', 11447784, 'azer191', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-27', '315904', 3, 'azer19199999.png'),
(73, 'ababa', 'anbbab', 'tunisia', 'abab@abab.tn', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 66882200, 'ababa', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-27', '237845', 3, 'ababa.png'),
(74, 'hassine', 'lakhal', 'Tunisia', 'lakhalhassine4@gmail.com', '$2a$10$OYty/sJuxGPcgxtIKQHiWeyB/I50EzIBK3N64AzqBfFOHz8H8ZH1.', 94448385, 'hassinel', NULL, NULL, 0, NULL, NULL, NULL, NULL, 'Formateur', '2021-03-27', '236965', 3, 'hassinel.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
