<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use App\Repository\ReclamationRepository;

/**
 * @ORM\Entity(repositoryClass=ReclamationRepository::class)
 */
class Reclamation
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var int|null
     *
     * @ORM\Column(name="Etudiant_id", type="integer", nullable=true)
     */
    private $etudiantId;



    /**
     * @var \DateTime
     *
     * @ORM\Column(name="dateEnvoie", type="datetime", nullable=false)
     */
    private $dateenvoie;



    /**
     * @var string
     *
     * @ORM\Column(name="titre", type="string", length=50, nullable=false)
     */
    private $titre;

    /**
     * @var string
     *
     * @Assert\NotBlank(message="description is required")
     * @ORM\Column(name="description", type="string", length=50, nullable=false)
     */
    private $description;

    /**
     * @var string|null
     *
     * @Assert\NotBlank(message="reponse is required")
     * @ORM\Column(name="reponse", type="string", length=50, nullable=true)
     */
    private $reponse;

    /**
     * @var string
     *
     * @Assert\NotBlank(message="nometudiant is required")
     * @ORM\Column(name="nomEtudiant", type="string", length=255, nullable=false)
     */
    private $nometudiant;

    /**
     * @ORM\ManyToOne(targetEntity=Status::class, inversedBy="reclamations")
     * @ORM\JoinColumn(nullable=false)
     */
    private $status;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEtudiantId(): ?int
    {
        return $this->etudiantId;
    }

    public function setEtudiantId(?int $etudiantId): self
    {
        $this->etudiantId = $etudiantId;

        return $this;
    }



    public function getDateenvoie(): ?\DateTimeInterface
    {
        return $this->dateenvoie;
    }

    public function setDateenvoie(\DateTimeInterface $dateenvoie): self
    {
        $this->dateenvoie = $dateenvoie;

        return $this;
    }



    public function getTitre(): ?string
    {
        return $this->titre;
    }

    public function setTitre(string $titre): self
    {
        $this->titre = $titre;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getReponse(): ?string
    {
        return $this->reponse;
    }

    public function setReponse(?string $reponse): self
    {
        $this->reponse = $reponse;

        return $this;
    }

    public function getNometudiant(): ?string
    {
        return $this->nometudiant;
    }

    public function setNometudiant(string $nometudiant): self
    {
        $this->nometudiant = $nometudiant;

        return $this;
    }

    public function getStatus(): ?Status
    {
        return $this->status;
    }

    public function setStatus(?Status $status): self
    {
        $this->status = $status;

        return $this;
    }


}
