<?php

namespace App\Repository;

use App\Entity\Ecole;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Ecole|null find($id, $lockMode = null, $lockVersion = null)
 * @method Ecole|null findOneBy(array $criteria, array $orderBy = null)
 * @method Ecole[]    findAll()
 * @method Ecole[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class EcoleRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Ecole::class);
    }

    // /**
    //  * @return Ecole[] Returns an array of Ecole objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('e.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /**
    * return Ecole[]
    */
    public function searchEcole(Ecole $ecole): ? array
    {

        $qb =  $this->createQueryBuilder('p')
            ->andWhere('p.nom = :nom')
            ->setParameter('nom', $ecole->getNom())
            ->getQuery();
            
            return $qb->execute();
        
    }

        /**
    * return Ecole[]
    */
    public function triEcoleASC(): ? array
    {

        $qb =  $this->createQueryBuilder('p')
            ->orderBy('p.nom', 'ASC')
            ->getQuery();
            
            return $qb->execute();
        
    }

    /**
    * return Ecole[]
    */
    public function triEcoleDES(): ? array
    {

        $qb =  $this->createQueryBuilder('p')
            ->orderBy('p.nom', 'DESC')
            ->getQuery();
            
            return $qb->execute();
        
    }
    
    public function findEcoles()
    {
        return $this->createQueryBuilder('a');
    }       
}
