<?php

namespace App\Entity;

use App\Repository\EcoleRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=EcoleRepository::class)
 */
class Ecole
{
    /**
     * @Groups({"Ecole","Module"})
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @Groups({"Ecole","Module"})
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @Groups({"Ecole"})
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $ville;

    /**
     * @Groups({"Ecole"})
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $rue;

    /**
     * @Groups({"Ecole"})
     * @ORM\Column(type="integer", nullable=true)
     */
    private $numMaison;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Module", mappedBy="ecole")
     */
    private $modules;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(?string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getVille(): ?string
    {
        return $this->ville;
    }

    public function setVille(string $ville): self
    {
        $this->ville = $ville;

        return $this;
    }

    public function getRue(): ?string
    {
        return $this->rue;
    }

    public function setRue(string $rue): self
    {
        $this->rue = $rue;

        return $this;
    }

    public function getNumMaison(): ?int
    {
        return $this->numMaison;
    }

    public function setNumMaison(int $numMaison): self
    {
        $this->numMaison = $numMaison;

        return $this;
    }

    /**
     * @return Collection|Product[]
     */
    public function getModules()
    {
        return $this->modules;
    }

    /**
     * Set the value of modules
     *
     * @return  self
     */
    public function setModules($modules)
    {
        $this->modules = $modules;

        return $this;
    }
}
