<?php

namespace App\Entity;

use App\Repository\ModuleRepository;
use Doctrine\ORM\Mapping as ORM;
use phpDocumentor\Reflection\Types\Integer;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass=ModuleRepository::class)
 */
class Module
{
    /**
     * @Groups({"Module"})
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @Groups({"Module"})
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $nom;

    /**
     * @Groups({"Module"})
     * @ORM\Column(type="integer", nullable=true)
     */
    private $coeficient;

    /**
     * @Groups({"Module"})
     * @ORM\ManyToOne(targetEntity="App\Entity\Ecole", inversedBy="modules")
     */
    private $ecole;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(?string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getCoeficient(): ?int
    {
        return $this->coeficient;
    }

    public function setCoeficient(?int $coeficient): self
    {
        $this->coeficient = $coeficient;

        return $this;
    }

    /**
     * Get the value of ecole
     */
    public function getEcole()
    {
        return $this->ecole;
    }

    /**
     * Set the value of ecole
     *
     * @return  self
     */
    public function setEcole($ecole)
    {
        $this->ecole = $ecole;

        return $this;
    }
}
