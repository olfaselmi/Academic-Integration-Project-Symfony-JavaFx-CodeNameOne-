<?php

namespace App\Form;

use App\Entity\Ecole;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class EcoleType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nom', TextType::class, [
                'attr' => [
                    'class' => 'form-control',
                    'placeholder'=>'Nom'
                ],
                'required' => true,

            ])
            ->add('ville', TextType::class, [
                'attr' => [
                    'class' => 'form-control',
                    'placeholder'=>'Ville'
                ],
                'required' => true,

            ])
            ->add('rue', TextType::class, [
                'attr' => [
                    'class' => 'form-control',
                    'placeholder'=>'Rue'
                ],
                'required' => true,

            ])
            ->add('numMaison', TextType::class, [
                'attr' => [
                    'class' => 'form-control',
                    'placeholder'=>'Numéro Maison'
                ],
                'required' => true,

            ])
            ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Ecole::class,
        ]);
    }
}
