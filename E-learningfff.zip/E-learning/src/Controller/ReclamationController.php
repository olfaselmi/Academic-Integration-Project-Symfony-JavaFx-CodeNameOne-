<?php

namespace App\Controller;

use App\Entity\Reclamation;
use App\Form\ReclamationType;
use App\Form\ReclamationUpdateStatusType;
use App\Repository\StatusRepository;
use App\Repository\ReclamationRepository;

use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/reclamation")
 */
class ReclamationController extends AbstractController
{
    /**
     * @Route("/", name="reclamation_index", methods={"GET","POST"})
     */
    public function index(Request $request,PaginatorInterface $paginator): Response
    {
        $reclamation = new Reclamation();
        $form = $this->createForm(ReclamationUpdateStatusType::class, $reclamation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {


            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($reclamation);
            $entityManager->flush();

            return $this->redirectToRoute('reclamation_index');
        }

        $reclamations = $this->getDoctrine()
            ->getRepository(Reclamation::class)
            ->findAll();
        $reclamations = $paginator->paginate(
            $reclamations,
            $request->query->getInt('page',1) ,
            3
        ) ;

        return $this->render('reclamation/index.html.twig', [
            'form'=> $form->createView(),
            'reclamations' => $reclamations,
        ]);
    }
    /**
     * @Route("/tria", name="reclamation_indexx", methods={"GET","POST"})
     */
    public function indexTria(Request $request,PaginatorInterface $paginator): Response
    {
        $reclamation = new Reclamation();
        $form = $this->createForm(ReclamationUpdateStatusType::class, $reclamation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {


            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($reclamation);
            $entityManager->flush();

            return $this->redirectToRoute('reclamation_indexx');
        }

        $reclamations = $this->getDoctrine()
            ->getRepository(Reclamation::class)
            ->ordered();
        $reclamations = $paginator->paginate(
            $reclamations,
            $request->query->getInt('page',1) ,
            3
        ) ;

        return $this->render('reclamation/index.html.twig', [
            'form'=> $form->createView(),
            'reclamations' => $reclamations,
        ]);
    }
    /**
     * @Route("/trid", name="reclamation_indexxx", methods={"GET","POST"})
     */
    public function indexTrid(Request $request,PaginatorInterface $paginator): Response
    {
        $reclamation = new Reclamation();
        $form = $this->createForm(ReclamationUpdateStatusType::class, $reclamation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {


            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($reclamation);
            $entityManager->flush();

            return $this->redirectToRoute('reclamation_indexxx');
        }

        $reclamations = $this->getDoctrine()
            ->getRepository(Reclamation::class)
            ->orderliness();
        $reclamations = $paginator->paginate(
            $reclamations,
            $request->query->getInt('page',1) ,
            3
        ) ;

        return $this->render('reclamation/index.html.twig', [
            'form'=> $form->createView(),
            'reclamations' => $reclamations,
        ]);
    }
    /**
     * @Route("/new", name="reclamation_new", methods={"GET","POST"})
     */
    public function new(Request $request,StatusRepository $statusRepository,\Swift_Mailer $mailer): Response
    {
        $reclamation = new Reclamation();
        $form = $this->createForm(ReclamationType::class, $reclamation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $status=$statusRepository->findOneBy(array("libelle"=>"en cours"));
            $reclamation->setStatus($status);
            $time = date('Y-m-d H:i:s', (time()));
            $reclamation->setDateenvoie(\DateTime::createFromFormat('Y-m-d H:i:s', $time));

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($reclamation);
            $entityManager->flush();
            $message = (new \Swift_Message('Reclamation'))
                ->setFrom('aminos.ayari@gmail.com')
                ->setTo('olfa.selmi@esprit.tn')
                ->setBody( "une nouvelle reclamation a propos de l'etudiant ".$reclamation->getNometudiant() )
            ;
            $mailer->send($message);

            return $this->redirectToRoute('reclamation_index2');
        }

        return $this->render('reclamation/new.html.twig', [
            'reclamation' => $reclamation,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="reclamation_show", methods={"GET"})
     */
    public function show(Reclamation $reclamation): Response
    {
        return $this->render('reclamation/show.html.twig', [
            'reclamation' => $reclamation,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="reclamation_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Reclamation $reclamation): Response
    {
        $form = $this->createForm(ReclamationUpdateStatusType::class, $reclamation);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('reclamation_index');
        }

        return $this->render('reclamation/edit.html.twig', [
            'reclamation' => $reclamation,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="reclamation_delete", methods={"POST"})
     */
    public function delete(Request $request, Reclamation $reclamation): Response
    {
        if ($this->isCsrfTokenValid('delete'.$reclamation->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($reclamation);
            $entityManager->flush();
        }

        return $this->redirectToRoute('reclamation_index');
    }

    /**
     * @Route("/front/afficher", name="reclamation_index2", methods={"GET","POST"})
     */
    public function index2(Request $request,PaginatorInterface $paginator): Response
    {

        $reclamations = $this->getDoctrine()
            ->getRepository(Reclamation::class)
            ->findAll();
        $reclamations = $paginator->paginate(
            $reclamations,
            $request->query->getInt('page',1) ,
            3
        ) ;

        return $this->render('reclamation/reclamationfront.html.twig', [
            'reclamations' => $reclamations,
        ]);
    }

    /**
     * @param Request $request
     * @return Response
     * @Route ("/ajax/aa",name="searchrdv")
     */
    public function searchtitre(Request $request)
    {
        $repository = $this->getDoctrine()->getRepository(Reclamation::class);
        $requestString=$request->get('searchValue');
        $rdv = $repository->findtitre($requestString);
        return $this->render('reclamation/backajax.html.twig' ,[
            "reclamations"=>$rdv
        ]);
    }
    /**
     * @param Request $request
     * @return Response
     * @Route ("/ajaxxx/aa",name="searchrdvv")
     */
    public function searchtitree(Request $request)
    {
        $repository = $this->getDoctrine()->getRepository(Reclamation::class);
        $requestString=$request->get('searchValue');
        $rdv = $repository->findtitre($requestString);
        return $this->render('reclamation/frontajax.html.twig' ,[
            "reclamations"=>$rdv
        ]);
    }

}
