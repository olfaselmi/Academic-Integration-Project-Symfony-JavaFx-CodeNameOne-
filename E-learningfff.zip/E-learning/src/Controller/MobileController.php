<?php
namespace App\Controller;

use App\Entity\Reclamation;
use App\Entity\Status;
use App\Form\ReclamationType;
use App\Repository\ReclamationRepository;


use App\Repository\StatusRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

class MobileController extends AbstractController
{
    /**
     * @Route("/mobile", name="mobile")
     */
    public function index(): Response
    {
        return $this->render('mobile/index.html.twig', [
            'controller_name' => 'MobileController',
        ]);
    }
  /*  /**
     * @Route("/listereclamation", name="listereclamation")

     */
  /*
    public function getCours():Response{
        $reclamation= $this->getDoctrine()->getManager()->getRepository(Reclamation::class)->findAll();
        $serializer = new Serializer([new ObjectNormalizer()]);
        $formatted = $serializer->normalize($reclamation);
        return new JsonResponse($formatted);
    }*/


    /**
     * @Route("/listereclamation", name="listereclamation")

     */
    public function indexMobile(ReclamationRepository $reclamationRepository, NormalizerInterface $normalizer)
    {

        $reclamation=$reclamationRepository->findAll();
        $json=$normalizer->normalize($reclamation,'json',['groups'=>'Reclamation']);
        return new Response(json_encode($json));

    }
    /**
     * @Route("/add", name="add_reclamation")
     */
    public function addReclamation(Request $request,StatusRepository $statusRepository){

        $status2 =new Status();
        $reclamation= new Reclamation();

        $status2=$statusRepository->findOneBy(array("libelle"=>"en cours"));
        $reclamation->setStatus($status2);


        $id= $request->query->get("id");
        $etudiantId= $request->query->get("etudiantId");
        $titre= $request->query->get("titre");
        $description= $request->query->get("description");
        $reponse= $request->query->get("reponse");
        $nometudiant= $request->query->get("nometudiant");


        $reclamation->setEtudiantId($etudiantId);
        $reclamation->setTitre($titre);
        $reclamation->setReponse($reponse);
        $reclamation->setDescription($description);
        $reclamation->setNometudiant($nometudiant);

        $time = date('Y-m-d H:i:s', (time()));
        $reclamation->setDateenvoie(\DateTime::createFromFormat('Y-m-d H:i:s', $time));

        $em=$this->getDoctrine()->getManager();
        $em->persist($reclamation);
        $em->flush();
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("Reclamation Ajoutée");
        return new JsonResponse($formatted);

    }
    /**
     * @Route("/deletereclamation", name="deletereclamation", methods={"GET","POST"})
     *
     */
    public function deletereclamation(Request $request){
        $id=$request->get('id');
        $entityManager = $this->getDoctrine()->getManager();
        $reclamation=$entityManager->getRepository(Reclamation::class)->find($id);
        if($reclamation!=null){
            $entityManager->remove($reclamation);
            $entityManager->flush();
            $serialize = new Serializer([new ObjectNormalizer()]);
            $formatted = $serialize->normalize("reclamation deleted");
            return new JsonResponse($formatted);
        }

    }
    /**
     * @Route("/updatestade", name="updatestade", methods={"GET","POST"})
     *
     */
    public function updateStade(Request $request){
        $em=$this->getDoctrine()->getManager();
        $reclamation=$this->getDoctrine()->getManager()->getRepository(Reclamation::class)->find($request->get("id"));
        $reclamation->setIdo($request->get("ido"));
        $reclamation->setSujet($request->get("sujet"));
        $reclamation->setDescription($request->get("description"));
        $reclamation->setIdu($request->get("idu"));
        $reclamation->setType($request->get("type"));
        $em->persist($reclamation);
        $em->flush();
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("Stade updated");
        return new JsonResponse($formatted);
    }


    /**
     * @Route("/detailreclamation", name="detailreclamation" , methods={"GET","POST"})
     *
     */



    public function Stadedetail(Request $request,ReclamationRepository $reclamationRepository,SerializerInterface $serializerinterface)
    { $id=$request->get('id');
        $repo = $reclamationRepository->find($id);

        $serializer = new Serializer([new ObjectNormalizer()]);
        $formatted = $serializer->normalize($repo);
        return new JsonResponse($formatted);

    }
}
