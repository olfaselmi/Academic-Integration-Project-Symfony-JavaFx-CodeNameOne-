<?php

namespace App\Controller;

use App\Entity\Module;
use App\Form\ModuleType;
use App\Repository\DomaineRepository;
use App\Repository\EcoleRepository;
use App\Repository\ModuleRepository;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use CMEN\GoogleChartsBundle\GoogleCharts\Charts\PieChart;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use CMEN\GoogleChartsBundle\GoogleCharts\Charts\Material\BarChart;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * @Route("/admin/modules")
 */
class ModuleController extends AbstractController
{

    /**
     * @Route("/", name="admin_module")
     */
    public function modules(): Response
    {
        return $this->render('admin/module/index.html.twig', [
            'controller_name' => 'ModuleController',
            'modules'=> $this->getDoctrine()->getRepository(Module::class)->findAll(),
        ]);

    }

    /**
     * @Route("/form", name="admin_module_form")
     */
    public function newModule(Request $request): Response
    {
        $module =new Module();
        $form = $this->createForm(ModuleType::class, $module);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($module);
            $this->getDoctrine()->getManager()->flush();
            $this->addFlash('success', 'Module ajouté avec succées');
            return $this->redirectToRoute('admin_module');
        }

            return $this->render('admin/module/form.html.twig', [
            'controller_name' => 'ModuleController',
            'form' => $form->createView(),
                'title'=>"Ajouter un nouveau module",
                'module'=>$module
        ]);
    }

    /**
     * @Route("/form/{id}", name="admin_module_edit")
     */
    public function editModule(Request $request , $id): Response
    {
        $module =$this->getDoctrine()->getRepository(Module::class)->find($id);
        $form = $this->createForm(ModuleType::class, $module);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($module);
            $this->getDoctrine()->getManager()->flush();
            $this->addFlash('success', 'Module modifié avec succées');
            return $this->redirectToRoute('admin_module');
        }

        return $this->render('admin/module/form.html.twig', [
            'controller_name' => 'ModuleController',
            'form' => $form->createView(),
            'title'=>"Modifier un module",
            'module'=>$module
        ]);
    }

    /**
     * @Route("/delete/{id}", name="admin_module_delete")
     */
    public function deleteModule($id): Response
    {
        $module =$this->getDoctrine()->getRepository(Module::class)->find($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($module);
        $em->flush();
        $this->addFlash('danger', 'Module supprimé avec succées');
        return $this->redirectToRoute('admin_module');

    }
    /**
     * 
     *@Route("/modStat",name ="stats")
     *Return Response
     */
    public function statsistque(): Response
    {
        $count =0;
        $countu = 0;
        $pieChart = new PieChart();
        $em = $this->getDoctrine()->getManager();
        $importantModule = $em->getRepository(Module::class)->findImportantModules();
        $optionModule = $em->getRepository(Module::class)->findOptionModules();
            $count = sizeof($importantModule);
            $countu = sizeof($optionModule); 
            $pieChart->getData()->setArrayToDataTable(
                [
                    
                    ['type de modules', 'percentage'],
                    [ 'important', $count ],
                    [ 'option', $countu ],

                ]
            );
         

        $pieChart->getOptions()->setPieSliceText('label');
        $pieChart->getOptions()->setTitle('type de modules');
        $pieChart->getOptions()->setPieStartAngle(100);
        $pieChart->getOptions()->setHeight(500);
        $pieChart->getOptions()->setWidth(900);
        $pieChart->getOptions()->getLegend()->setPosition('none');
    
        $bar = new BarChart();
        $bar->getData()->setArrayToDataTable([
            ['type de modules', 'percentage'],
            [ 'important', $count ],
            [ 'option', $countu ],
        ]);
        $bar->getOptions()->setTitle('type de modules');
        $bar->getOptions()->getHAxis()->setTitle('type de modules');
        $bar->getOptions()->getHAxis()->setMinValue(0);
        $bar->getOptions()->getVAxis()->setTitle('module');
        $bar->getOptions()->setWidth(900);
        $bar->getOptions()->setHeight(500);
        return $this->render('admin/module/stats.html.twig', ['piechart' => $pieChart, 'bar' => $bar]);
    }

    /**
     * @Route("/mobile/listemodule", name="listeModule")
     */
    public function indexMobile(ModuleRepository $ModuleRepository, NormalizerInterface $normalizer)
    {

        $Module=$ModuleRepository->findAll();
        $json=$normalizer->normalize($Module,'json',['groups'=>'Module']);
        return new Response(json_encode($json));

    }
    /**
     * @Route("/mobile/add", name="add_Module")
     */
    public function addMobile(Request $request,EcoleRepository $ecoleRepository){

        $Module= new Module();

        $nom= $request->query->get("nom");
        $Module->setNom($nom);

        $coeficient= $request->query->get("coeficient");
        $Module->setcoeficient($coeficient);

        $et= $request->query->get("ecole");

        $ecole=$ecoleRepository->findOneBy(["nom"=>$et]);

        $Module->setEcole($ecole);


        $em=$this->getDoctrine()->getManager();
        $em->persist($Module);
        $em->flush();
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("Module Ajoute");
        return new JsonResponse($formatted);

    }

    /**
     * @Route("/mobile/delete/{id}", name="admin_Module_delete_mobile")
     */
    public function deleteMobile($id,Request $request): Response
    {
        $Module =$this->getDoctrine()->getRepository(Module::class)->find($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($Module);
        $em->flush();
        $this->addFlash('danger', 'Module supprimé avec succées');
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("Module supprimer");
        return new JsonResponse($formatted);
    }
}
