<?php

namespace App\Controller;


namespace App\Controller;


use App\Entity\Ecole;
use App\Entity\Etudiant;
use App\Entity\Formation;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


/**
 * @Route("/ecoles")
 */
class EcoleFrontController extends AbstractController
{

    /**
     * @Route("/", name="ecoles")
     */
    public function ecoles(): Response
    {
        $ecole=$this->getDoctrine()->getRepository(Ecole::class)->findAll();
        return $this->render('front/ecole/index.html.twig', [
            'controller_name' => 'EcoleFrontController',
            'ecoles'=> $ecole,
        ]);

    }
    /**
     * @Route("/{id}", name="ecole_show")
     */
    public function showEcole($id): Response
    {
        $ecole =$this->getDoctrine()->getRepository(Ecole::class)->find($id);
        return $this->render('front/ecole/show.html.twig', [
            'controller_name' => 'EcoleFrontController',
            'ecole'=> $ecole
        ]);
    }

}
