<?php

namespace App\Controller;



use App\Entity\Centre;
use App\Entity\Ecole;
use App\Form\EcoleType;
use App\Repository\EcoleRepository;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * @Route("/admin/ecoles")
 */
class EcoleController extends AbstractController
{

    /**
     * @Route("/", name="admin_ecole")
     */
    public function ecoles(): Response
    {
        return $this->render('admin/ecole/index.html.twig', [
            'controller_name' => 'EcoleController',
            'ecoles'=> $this->getDoctrine()->getRepository(Ecole::class)->findAll(),
        ]);

    }

    /**
     * @Route("/form", name="admin_ecole_form")
     */
    public function newEcole(Request $request): Response
    {
        $ecole =new Ecole();
        $form = $this->createForm(EcoleType::class, $ecole);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($ecole);
            $this->getDoctrine()->getManager()->flush();
            $this->addFlash('success', 'Ecole ajouté avec succées');
            return $this->redirectToRoute('admin_ecole');
        }

            return $this->render('admin/ecole/form.html.twig', [
            'controller_name' => 'EcoleController',
            'form' => $form->createView(),
                'title'=>"Ajouter un nouveau ecole",
                'ecole'=>$ecole
        ]);
    }

    /**
     * @Route("/form/{id}", name="admin_ecole_edit")
     */
    public function editEcole(Request $request , $id): Response
    {
        $ecole =$this->getDoctrine()->getRepository(Ecole::class)->find($id);
        $form = $this->createForm(EcoleType::class, $ecole);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($ecole);
            $this->getDoctrine()->getManager()->flush();
            $this->addFlash('success', 'Ecole modifié avec succées');
            return $this->redirectToRoute('admin_ecole');
        }

        return $this->render('admin/ecole/form.html.twig', [
            'controller_name' => 'EcoleController',
            'form' => $form->createView(),
            'title'=>"Modifier un ecole",
            'ecole'=>$ecole
        ]);
    }

    /**
     * @Route("/delete/{id}", name="admin_ecole_delete")
     */
    public function deleteEcole($id): Response
    {
        $ecole =$this->getDoctrine()->getRepository(Ecole::class)->find($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($ecole);
        $em->flush();
        $this->addFlash('danger', 'Ecole supprimé avec succées');
        return $this->redirectToRoute('admin_ecole');

    }

    /**
     * @Route("/mobile/listeecole", name="listeecole")

     */
    public function indexMobile(EcoleRepository $ecoleRepository, NormalizerInterface $normalizer)
    {

        $centre=$ecoleRepository->findAll();
        $json=$normalizer->normalize($centre,'json',['groups'=>'Ecole']);
        return new Response(json_encode($json));

    }

    /**
     * @Route("/mobile/add", name="add_ecole")
     */
    public function addMobile(Request $request,EcoleRepository $ecoleRepository){

        $ecole= new Ecole();

        $nom= $request->query->get("nom");
        $ecole->setNom($nom);

        $maison= $request->query->get("maison");
        $ecole->setNumMaison($maison);

        $rue= $request->query->get("rue");
        $ecole->setRue($rue);

        $ville= $request->query->get("ville");
        $ecole->setVille($ville);

        $ville= $request->query->get("ville");
        $ecole->setNumMaison($ville);



        $em=$this->getDoctrine()->getManager();
        $em->persist($ecole);
        $em->flush();
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("Ecole Ajoutee");
        return new JsonResponse($formatted);

    }

    /**
     * @Route("/mobile/delete/{id}", name="admin_ecole_delete_mobile")
     */
    public function deleteMobile($id,Request $request): Response
    {
        $ecole =$this->getDoctrine()->getRepository(ecole::class)->find($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($ecole);
        $em->flush();
        $this->addFlash('danger', 'Ecole supprimé avec succées');
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("Ecole supprimer");
        return new JsonResponse($formatted);
    }
}
