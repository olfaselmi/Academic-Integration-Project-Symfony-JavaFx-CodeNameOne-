<?php

namespace App\Controller;


use App\Entity\Centre;
use App\Entity\Cours;
use App\Entity\Domaine;
use App\Form\CentreType;
use App\Form\CoursType;
use App\Repository\CentreRepository;
use App\Repository\DomaineRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * @Route("/admin/centres")
 */
class CentreController extends AbstractController
{

    /**
     * @Route("/", name="admin_centre")
     */
    public function cours(): Response
    {
        return $this->render('admin/centre/index.html.twig', [
            'controller_name' => 'CentreController',
            'centres'=> $this->getDoctrine()->getRepository(Centre::class)->findAll(),
        ]);

    }

    /**
     * @Route("/form", name="admin_centre_form")
     */
    public function newCentre(Request $request): Response
    {
        $centre =new Centre();
        $form = $this->createForm(CentreType::class, $centre);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            /** @var UploadedFile $uploadedFile */
            $uploadedFile = $form['file']->getData();
            if ($uploadedFile) {
                $destination = $this->getParameter('kernel.project_dir') . '/public/centre';
                $newFilename = 'centre-logo-'.uniqid() .".". $uploadedFile->guessExtension();
                $uploadedFile->move(
                    $destination,
                    $newFilename
                );
                $centre->setFile($newFilename);
            }
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($centre);
            $this->getDoctrine()->getManager()->flush();
            $this->addFlash('success', 'Centre ajouté avec succées');
            return $this->redirectToRoute('admin_centre');
        }

            return $this->render('admin/centre/form.html.twig', [
            'controller_name' => 'CentreController',
            'form' => $form->createView(),
                'title'=>"Ajouter un nouveau centre",
                'centre'=>$centre
        ]);
    }

    /**
     * @Route("/form/{id}", name="admin_centre_edit")
     */
    public function editCentre(Request $request , $id): Response
    {
        $centre =$this->getDoctrine()->getRepository(Centre::class)->find($id);
        $form = $this->createForm(CentreType::class, $centre);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            /** @var UploadedFile $uploadedFile */
            $uploadedFile = $form['file']->getData();
            if ($uploadedFile) {
                $destination = $this->getParameter('kernel.project_dir') . '/public/centre';
                $newFilename = 'centre-logo-'.uniqid() .".". $uploadedFile->guessExtension();
                $uploadedFile->move(
                    $destination,
                    $newFilename
                );
                $centre->setFile($newFilename);
            }
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($centre);
            $this->getDoctrine()->getManager()->flush();
            $this->addFlash('success', 'Centre modifié avec succées');
            return $this->redirectToRoute('admin_centre');
        }

        return $this->render('admin/centre/form.html.twig', [
            'controller_name' => 'CentreController',
            'form' => $form->createView(),
            'title'=>"Modifier un centre",
            'centre'=>$centre
        ]);
    }

    /**
     * @Route("/delete/{id}", name="admin_centre_delete")
     */
    public function deletecentre($id): Response
    {
        $centre =$this->getDoctrine()->getRepository(Centre::class)->find($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($centre);
        $em->flush();
        $this->addFlash('danger', 'Centre supprimé avec succées');
        return $this->redirectToRoute('admin_centre');

    }
    /**
     * @Route("/mobile/listecentre", name="listecentre")
     */
    public function indexMobile(CentreRepository $centreRepository, NormalizerInterface $normalizer)
    {

        $centre=$centreRepository->findAll();
        $json=$normalizer->normalize($centre,'json',['groups'=>'Centre']);
        return new Response(json_encode($json));

    }
    /**
     * @Route("/mobile/add", name="add_centre")
     */
    public function addMobile(Request $request,DomaineRepository $domaineRepository){

        $centre= new Centre();

        $nom= $request->query->get("nom");
        $centre->setNom($nom);

        $maison= $request->query->get("maison");
        $centre->setNumMaison($maison);

        $rue= $request->query->get("rue");
        $centre->setRue($rue);

        $ville= $request->query->get("ville");
        $centre->setVille($ville);

        $ville= $request->query->get("ville");
        $centre->setNumMaison($ville);


        $domaine= $request->query->get("domaine");
        $domaineobj=$domaineRepository->findOneBy(["name"=> $domaine]);
        $centre->setDomaine($domaineobj);

        $centre->setFile(" ");

        $em=$this->getDoctrine()->getManager();
        $em->persist($centre);
        $em->flush();
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("centre Ajoute");
        return new JsonResponse($formatted);

    }

    /**
     * @Route("/mobile/delete/{id}", name="admin_centre_delete_mobile")
     */
    public function deleteMobile($id,Request $request): Response
    {
        $centre =$this->getDoctrine()->getRepository(centre::class)->find($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($centre);
        $em->flush();
        $this->addFlash('danger', 'centre supprimé avec succées');
        $serialize = new Serializer([new ObjectNormalizer()]);
        $formatted = $serialize->normalize("centre supprimer");
        return new JsonResponse($formatted);
    }
}
