<?php

namespace App\Controller;


namespace App\Controller;


use App\Entity\Module;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


/**
 * @Route("/modules")
 */
class ModuleFrontController extends AbstractController
{

    /**
     * @Route("/", name="modules")
     */
    public function modules(): Response
    {
        $modules=$this->getDoctrine()->getRepository(Module::class)->findAll();
        return $this->render('front/module/index.html.twig', [
            'controller_name' => 'ModuleFrontController',
            'modules'=> $modules,
        ]);

    }
    /**
     * @Route("/{id}", name="module_show")
     */
    public function showModule($id): Response
    {
        $module =$this->getDoctrine()->getRepository(Module::class)->find($id);
        return $this->render('front/module/show.html.twig', [
            'controller_name' => 'ModuleFrontController',
            'module'=> $module
        ]);
    }

}
