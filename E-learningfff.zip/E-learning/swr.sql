-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : mer. 28 avr. 2021 à 14:24
-- Version du serveur :  8.0.23-0ubuntu0.20.04.1
-- Version de PHP : 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `swr`
--

-- --------------------------------------------------------

--
-- Structure de la table `centre`
--

CREATE TABLE `centre` (
  `id` int NOT NULL,
  `domaine_id` int DEFAULT NULL,
  `nom` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numMaison` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ville` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rue` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `centre`
--

INSERT INTO `centre` (`id`, `domaine_id`, `nom`, `numMaison`, `ville`, `rue`, `file`) VALUES
(3, 1, 'Expert .net', '20', 'Tunisa', 'Lafyette', 'centre-logo-6087c1409bf14.png'),
(4, 1, 'Centre Lyom', '1205', 'Lyon', 'Lyon', 'centre-logo-6087c15bde436.png'),
(5, 5, 'Centre Mongo', '20', 'Tunis', 'Lafyette', 'centre-logo-6087c5d3467fc.png');

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

CREATE TABLE `cours` (
  `id` int NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contenu` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateD` date NOT NULL,
  `dateF` date NOT NULL,
  `placeDispo` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idEnseig` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `cours`
--

INSERT INTO `cours` (`id`, `titre`, `contenu`, `dateD`, `dateF`, `placeDispo`, `image`, `file`, `idEnseig`) VALUES
(4, 'Online Literature Course', 'Maecenas rutru', '2021-04-17', '2021-04-29', '5', 'cours-image-607d66ccdac29.jpeg', 'cours-file-607d5e1b42ec5.png', 2),
(8, 'Online Literature Course', 'there is problem on returning Arabic text, as they are words with combined letters if the second parameter(100) is not at end of Arabic words on the last while counting 100 it will return null. for that we will use(mb_substr($big,0,100)', '2021-04-17', '2021-04-28', '20', 'cours-image-607d66dd48826.jpeg', 'cours-file-607d667320d27.png', 2),
(9, 'Online Marketing Course', 'Maecenas rutrum viverra sapien sed ferm entum. Morbi tempor odio eget lacus tempus pulvinar.', '2021-04-17', '2021-04-30', '85', 'cours-image-607d66fbe361b.jpeg', 'cours-file-607d66fbe36cc.png', 2),
(10, 'Social Media Course', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam pharetra pharetra nisl, id blandit nisi tincidunt et. Morbi sapien sem, faucibus eget nulla id, maximus lacinia neque. Vestibulum vitae est nibh. Fusce eu fringilla nulla. Interdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur mollis luctus posuere. Donec a elementum erat, commodo iaculis sapien. Nam semper egestas quam ut dignissim. Nam ac dolor pulvinar, facilisis leo sed, tincidunt eros. Fusce ac commodo neque. Sed a magna egestas, malesuada felis at, cursus lacus.\r\n\r\nNulla in odio urna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque tristique consequat magna eget eleifend. Nunc non tortor nec elit lacinia consectetur. In tincidunt porttitor turpis. Aliquam cursus tincidunt neque sit amet pulvinar. Maecenas at odio tincidunt ante commodo pretium eget tincidunt metus. Mauris eu augue bibendum elit condimentum elementum at scelerisque sem erat curae.', '2021-04-19', '2021-04-28', '85', 'cours-image-607d674d58b6f.jpeg', 'cours-file-607d674d58c2b.png', 2),
(14, 'Social Media Course', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam pharetra pharetra nisl, id blandit nisi tincidunt et. Morbi sapien sem, faucibus eget nulla id, maximus lacinia neque. Vestibulum vitae est nibh. Fusce eu fringilla nulla. Interdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur mollis luctus posuere. Donec a elementum erat, commodo iaculis sapien. Nam semper egestas quam ut dignissim. Nam ac dolor pulvinar, facilisis leo sed, tincidunt eros. Fusce ac commodo neque. Sed a magna egestas, malesuada felis at, cursus lacus. Nulla in odio urna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque tristique consequat magna eget eleifend. Nunc non tortor nec elit lacinia consectetur. In tincidunt porttitor turpis. Aliquam cursus tincidunt neque sit amet pulvinar. Maecenas at odio tincidunt ante commodo pretium eget tincidunt metus. Mauris eu augue bibendum elit condimentum elementum at scelerisque sem', '2021-05-01', '2021-05-08', '85', 'cours-image-60891868d6d46.png', 'cours-file-60891868d76ea.png', 2),
(15, 'Social Media Course', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam pharetra pharetra nisl, id blandit nisi tincidunt et. Morbi sapien sem, faucibus eget nulla id, maximus lacinia neque. Vestibulum vitae est nibh. Fusce eu fringilla nulla. Interdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur mollis luctus posuere. Donec a elementum erat, commodo iaculis sapien. Nam semper egestas quam ut dignissim. Nam ac dolor pulvinar, facilisis leo sed, tincidunt eros. Fusce ac commodo neque. Sed a magna egestas, malesuada felis at, cursus lacus. Nulla in odio urna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque tristique consequat magna eget eleifend. Nunc non tortor nec elit lacinia consectetur. In tincidunt porttitor turpis. Aliquam cursus tincidunt neque sit amet pulvinar. Maecenas at odio tincidunt ante commodo pretium eget tincidunt metus. Mauris eu augue bibendum elit condimentum elementum at scelerisque sem', '2021-05-08', '2021-05-09', '85', 'cours-image-6089189c4e779.png', 'cours-file-6089189c4ea62.png', 2);

-- --------------------------------------------------------

--
-- Structure de la table `domaine`
--

CREATE TABLE `domaine` (
  `id` int NOT NULL,
  `nom` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `domaine`
--

INSERT INTO `domaine` (`id`, `nom`) VALUES
(1, 'Embarqué'),
(3, 'IT'),
(4, 'Aérospatiale'),
(5, 'Cloud');

-- --------------------------------------------------------

--
-- Structure de la table `domaine_formateur`
--

CREATE TABLE `domaine_formateur` (
  `id` int NOT NULL,
  `idDomaine` int DEFAULT NULL,
  `idFormateur` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `domaine_formateur`
--

INSERT INTO `domaine_formateur` (`id`, `idDomaine`, `idFormateur`) VALUES
(8, 1, 25),
(9, 3, 25),
(10, 5, 25),
(11, 4, 2);

-- --------------------------------------------------------

--
-- Structure de la table `enseignant`
--

CREATE TABLE `enseignant` (
  `id` int NOT NULL,
  `salaire` double NOT NULL,
  `idUser` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `enseignant`
--

INSERT INTO `enseignant` (`id`, `salaire`, `idUser`) VALUES
(2, 800, 5);

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `id` int NOT NULL,
  `active` tinyint(1) NOT NULL,
  `niveau` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idUser` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`id`, `active`, `niveau`, `idUser`) VALUES
(1, 1, '3', 2),
(2, 1, '3', 3);

-- --------------------------------------------------------

--
-- Structure de la table `etudiant_cours`
--

CREATE TABLE `etudiant_cours` (
  `id` int NOT NULL,
  `idCours` int DEFAULT NULL,
  `idEtudiant` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `etudiant_cours`
--

INSERT INTO `etudiant_cours` (`id`, `idCours`, `idEtudiant`) VALUES
(1, 4, 1),
(2, 4, 2);

-- --------------------------------------------------------

--
-- Structure de la table `etudiant_formation`
--

CREATE TABLE `etudiant_formation` (
  `id` int NOT NULL,
  `idFormation` int DEFAULT NULL,
  `idEtudiant` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `etudiant_formation`
--

INSERT INTO `etudiant_formation` (`id`, `idFormation`, `idEtudiant`) VALUES
(1, 12, 1);

-- --------------------------------------------------------

--
-- Structure de la table `formateur`
--

CREATE TABLE `formateur` (
  `id` int NOT NULL,
  `salaire` double NOT NULL,
  `idUser` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `formateur`
--

INSERT INTO `formateur` (`id`, `salaire`, `idUser`) VALUES
(2, 500, 1),
(25, 7800, 3);

-- --------------------------------------------------------

--
-- Structure de la table `formation`
--

CREATE TABLE `formation` (
  `id` int NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contenu` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `placeDispo` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idFormateur` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `formation`
--

INSERT INTO `formation` (`id`, `titre`, `image`, `file`, `contenu`, `placeDispo`, `idFormateur`) VALUES
(12, 'formation 2', 'formation-image-607d77434d941.jpeg', 'formation-file-607d77434e33b.png', 'Designed by English experts, our online English classes and courses provide a safe, inclusive learning community. Our highly qualified teachers help learners improve their English speaking, listening, reading and writing skills online, build their confidence and achieve their goals.', '5', 2),
(14, 'formation 3', 'formation-image-607d777f305e0.jpeg', 'formation-file-607d777f307ac.png', 'Dans son livre « Apprendre… oui mais comment » (ESF 1987), Philippe Meirieu parle « d’identifier les notions noyaux qui représentent un progrès décisif dans la progression de l’élève ». En d’autres termes, au regard des objectifs pédagogiques visés, du public (ses pré-acquis, ses besoins) et du format de la formation (module e-learning de 30mn ? présentiel de 2 jours ?) dégager les concepts clés', '22', 25);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int NOT NULL,
  `cin` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int NOT NULL,
  `tel` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `motDePasse` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numMaison` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rue` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ville` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `cin`, `nom`, `prenom`, `age`, `tel`, `email`, `motDePasse`, `numMaison`, `rue`, `ville`, `role`) VALUES
(1, '13001074', 'Jallali', 'Seif Allah', 27, '21554529', 'seifallah.jallali@esprit.tn', '+apzzpkzeojisni', '25', 'Denden', 'Tunis', ''),
(2, '13001087', 'Maryem', 'Khatat', 23, '25487998', 'emna.tekaka@esprit.tn', 'z87z7z94xw1x', '25', 'Ennaser', 'Tunis', ''),
(3, '10006784', 'Nasri', 'Mbarka', 50, '21587988', 'saifallah@pentabell.fr', '+apzzpkzeojisni', '25', 'Denden', 'Tunis', ''),
(5, '0256246', 'emna', 'ketata', 22, '55555555', 'emna@esprit.tn', 'aa', '52', 'test', 'test', 'test');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `centre`
--
ALTER TABLE `centre`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_C6A0EA754272FC9F` (`domaine_id`);

--
-- Index pour la table `cours`
--
ALTER TABLE `cours`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FDCA8C9CFC977C50` (`idEnseig`);

--
-- Index pour la table `domaine`
--
ALTER TABLE `domaine`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `domaine_formateur`
--
ALTER TABLE `domaine_formateur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FBADD08F6816613E` (`idDomaine`),
  ADD KEY `IDX_FBADD08F119C5519` (`idFormateur`);

--
-- Index pour la table `enseignant`
--
ALTER TABLE `enseignant`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_81A72FA1FE6E88D7` (`idUser`);

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_717E22E3FE6E88D7` (`idUser`);

--
-- Index pour la table `etudiant_cours`
--
ALTER TABLE `etudiant_cours`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_82F0A080EA0ECF81` (`idCours`),
  ADD KEY `IDX_82F0A08022DD08B8` (`idEtudiant`);

--
-- Index pour la table `etudiant_formation`
--
ALTER TABLE `etudiant_formation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_8ECBC4C8BCAA0AE9` (`idFormation`),
  ADD KEY `IDX_8ECBC4C822DD08B8` (`idEtudiant`);

--
-- Index pour la table `formateur`
--
ALTER TABLE `formateur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_ED767E4FFE6E88D7` (`idUser`);

--
-- Index pour la table `formation`
--
ALTER TABLE `formation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_404021BF119C5519` (`idFormateur`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `centre`
--
ALTER TABLE `centre`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `cours`
--
ALTER TABLE `cours`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `domaine`
--
ALTER TABLE `domaine`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `domaine_formateur`
--
ALTER TABLE `domaine_formateur`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `enseignant`
--
ALTER TABLE `enseignant`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `etudiant`
--
ALTER TABLE `etudiant`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `etudiant_cours`
--
ALTER TABLE `etudiant_cours`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `etudiant_formation`
--
ALTER TABLE `etudiant_formation`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `formateur`
--
ALTER TABLE `formateur`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `formation`
--
ALTER TABLE `formation`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `centre`
--
ALTER TABLE `centre`
  ADD CONSTRAINT `FK_C6A0EA754272FC9F` FOREIGN KEY (`domaine_id`) REFERENCES `domaine` (`id`);

--
-- Contraintes pour la table `cours`
--
ALTER TABLE `cours`
  ADD CONSTRAINT `FK_FDCA8C9CFC977C50` FOREIGN KEY (`idEnseig`) REFERENCES `enseignant` (`id`);

--
-- Contraintes pour la table `domaine_formateur`
--
ALTER TABLE `domaine_formateur`
  ADD CONSTRAINT `FK_FBADD08F119C5519` FOREIGN KEY (`idFormateur`) REFERENCES `formateur` (`id`),
  ADD CONSTRAINT `FK_FBADD08F6816613E` FOREIGN KEY (`idDomaine`) REFERENCES `domaine` (`id`);

--
-- Contraintes pour la table `enseignant`
--
ALTER TABLE `enseignant`
  ADD CONSTRAINT `FK_81A72FA1FE6E88D7` FOREIGN KEY (`idUser`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `FK_717E22E3FE6E88D7` FOREIGN KEY (`idUser`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `etudiant_cours`
--
ALTER TABLE `etudiant_cours`
  ADD CONSTRAINT `FK_82F0A08022DD08B8` FOREIGN KEY (`idEtudiant`) REFERENCES `etudiant` (`id`),
  ADD CONSTRAINT `FK_82F0A080EA0ECF81` FOREIGN KEY (`idCours`) REFERENCES `cours` (`id`);

--
-- Contraintes pour la table `etudiant_formation`
--
ALTER TABLE `etudiant_formation`
  ADD CONSTRAINT `FK_8ECBC4C822DD08B8` FOREIGN KEY (`idEtudiant`) REFERENCES `etudiant` (`id`),
  ADD CONSTRAINT `FK_8ECBC4C8BCAA0AE9` FOREIGN KEY (`idFormation`) REFERENCES `formation` (`id`);

--
-- Contraintes pour la table `formateur`
--
ALTER TABLE `formateur`
  ADD CONSTRAINT `FK_ED767E4FFE6E88D7` FOREIGN KEY (`idUser`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `formation`
--
ALTER TABLE `formation`
  ADD CONSTRAINT `FK_404021BF119C5519` FOREIGN KEY (`idFormateur`) REFERENCES `formateur` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
