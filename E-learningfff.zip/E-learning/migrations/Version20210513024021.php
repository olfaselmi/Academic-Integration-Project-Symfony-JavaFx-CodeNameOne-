<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210513024021 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE centre (id INT AUTO_INCREMENT NOT NULL, domaine_id INT DEFAULT NULL, nom VARCHAR(30) NOT NULL, numMaison VARCHAR(20) NOT NULL, ville VARCHAR(20) NOT NULL, rue VARCHAR(35) NOT NULL, file VARCHAR(250) NOT NULL, INDEX IDX_C6A0EA754272FC9F (domaine_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE cours (id INT AUTO_INCREMENT NOT NULL, titre VARCHAR(255) NOT NULL, contenu LONGTEXT NOT NULL, dateD DATE NOT NULL, dateF DATE NOT NULL, placeDispo VARCHAR(25) NOT NULL, image VARCHAR(250) NOT NULL, file VARCHAR(250) NOT NULL, idEnseig INT DEFAULT NULL, INDEX IDX_FDCA8C9CFC977C50 (idEnseig), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE domaine (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(30) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE domaine_formateur (id INT AUTO_INCREMENT NOT NULL, idDomaine INT DEFAULT NULL, idFormateur INT DEFAULT NULL, INDEX IDX_FBADD08F6816613E (idDomaine), INDEX IDX_FBADD08F119C5519 (idFormateur), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE enseignant (id INT AUTO_INCREMENT NOT NULL, salaire DOUBLE PRECISION NOT NULL, idUser INT DEFAULT NULL, INDEX IDX_81A72FA1FE6E88D7 (idUser), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE etudiant (id INT AUTO_INCREMENT NOT NULL, active TINYINT(1) NOT NULL, niveau VARCHAR(20) NOT NULL, idUser INT DEFAULT NULL, INDEX IDX_717E22E3FE6E88D7 (idUser), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE etudiant_cours (id INT AUTO_INCREMENT NOT NULL, idCours INT DEFAULT NULL, idEtudiant INT DEFAULT NULL, INDEX IDX_82F0A080EA0ECF81 (idCours), INDEX IDX_82F0A08022DD08B8 (idEtudiant), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE etudiant_formation (id INT AUTO_INCREMENT NOT NULL, idFormation INT DEFAULT NULL, idEtudiant INT DEFAULT NULL, INDEX IDX_8ECBC4C8BCAA0AE9 (idFormation), INDEX IDX_8ECBC4C822DD08B8 (idEtudiant), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE formateur (id INT AUTO_INCREMENT NOT NULL, salaire DOUBLE PRECISION NOT NULL, idUser INT DEFAULT NULL, INDEX IDX_ED767E4FFE6E88D7 (idUser), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE formation (id INT AUTO_INCREMENT NOT NULL, titre VARCHAR(255) NOT NULL, image VARCHAR(250) NOT NULL, file VARCHAR(250) NOT NULL, contenu LONGTEXT NOT NULL, placeDispo VARCHAR(250) NOT NULL, idFormateur INT DEFAULT NULL, INDEX IDX_404021BF119C5519 (idFormateur), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE utilisateur (id INT AUTO_INCREMENT NOT NULL, cin VARCHAR(8) NOT NULL, nom VARCHAR(30) NOT NULL, prenom VARCHAR(30) NOT NULL, age INT NOT NULL, tel VARCHAR(8) NOT NULL, email VARCHAR(30) NOT NULL, motDePasse VARCHAR(30) NOT NULL, numMaison VARCHAR(20) NOT NULL, rue VARCHAR(35) NOT NULL, ville VARCHAR(20) NOT NULL, role VARCHAR(25) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE centre ADD CONSTRAINT FK_C6A0EA754272FC9F FOREIGN KEY (domaine_id) REFERENCES domaine (id)');
        $this->addSql('ALTER TABLE cours ADD CONSTRAINT FK_FDCA8C9CFC977C50 FOREIGN KEY (idEnseig) REFERENCES enseignant (id)');
        $this->addSql('ALTER TABLE domaine_formateur ADD CONSTRAINT FK_FBADD08F6816613E FOREIGN KEY (idDomaine) REFERENCES domaine (id)');
        $this->addSql('ALTER TABLE domaine_formateur ADD CONSTRAINT FK_FBADD08F119C5519 FOREIGN KEY (idFormateur) REFERENCES formateur (id)');
        $this->addSql('ALTER TABLE enseignant ADD CONSTRAINT FK_81A72FA1FE6E88D7 FOREIGN KEY (idUser) REFERENCES utilisateur (id)');
        $this->addSql('ALTER TABLE etudiant ADD CONSTRAINT FK_717E22E3FE6E88D7 FOREIGN KEY (idUser) REFERENCES utilisateur (id)');
        $this->addSql('ALTER TABLE etudiant_cours ADD CONSTRAINT FK_82F0A080EA0ECF81 FOREIGN KEY (idCours) REFERENCES cours (id)');
        $this->addSql('ALTER TABLE etudiant_cours ADD CONSTRAINT FK_82F0A08022DD08B8 FOREIGN KEY (idEtudiant) REFERENCES etudiant (id)');
        $this->addSql('ALTER TABLE etudiant_formation ADD CONSTRAINT FK_8ECBC4C8BCAA0AE9 FOREIGN KEY (idFormation) REFERENCES formation (id)');
        $this->addSql('ALTER TABLE etudiant_formation ADD CONSTRAINT FK_8ECBC4C822DD08B8 FOREIGN KEY (idEtudiant) REFERENCES etudiant (id)');
        $this->addSql('ALTER TABLE formateur ADD CONSTRAINT FK_ED767E4FFE6E88D7 FOREIGN KEY (idUser) REFERENCES utilisateur (id)');
        $this->addSql('ALTER TABLE formation ADD CONSTRAINT FK_404021BF119C5519 FOREIGN KEY (idFormateur) REFERENCES formateur (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE etudiant_cours DROP FOREIGN KEY FK_82F0A080EA0ECF81');
        $this->addSql('ALTER TABLE centre DROP FOREIGN KEY FK_C6A0EA754272FC9F');
        $this->addSql('ALTER TABLE domaine_formateur DROP FOREIGN KEY FK_FBADD08F6816613E');
        $this->addSql('ALTER TABLE cours DROP FOREIGN KEY FK_FDCA8C9CFC977C50');
        $this->addSql('ALTER TABLE etudiant_cours DROP FOREIGN KEY FK_82F0A08022DD08B8');
        $this->addSql('ALTER TABLE etudiant_formation DROP FOREIGN KEY FK_8ECBC4C822DD08B8');
        $this->addSql('ALTER TABLE domaine_formateur DROP FOREIGN KEY FK_FBADD08F119C5519');
        $this->addSql('ALTER TABLE formation DROP FOREIGN KEY FK_404021BF119C5519');
        $this->addSql('ALTER TABLE etudiant_formation DROP FOREIGN KEY FK_8ECBC4C8BCAA0AE9');
        $this->addSql('ALTER TABLE enseignant DROP FOREIGN KEY FK_81A72FA1FE6E88D7');
        $this->addSql('ALTER TABLE etudiant DROP FOREIGN KEY FK_717E22E3FE6E88D7');
        $this->addSql('ALTER TABLE formateur DROP FOREIGN KEY FK_ED767E4FFE6E88D7');
        $this->addSql('DROP TABLE centre');
        $this->addSql('DROP TABLE cours');
        $this->addSql('DROP TABLE domaine');
        $this->addSql('DROP TABLE domaine_formateur');
        $this->addSql('DROP TABLE enseignant');
        $this->addSql('DROP TABLE etudiant');
        $this->addSql('DROP TABLE etudiant_cours');
        $this->addSql('DROP TABLE etudiant_formation');
        $this->addSql('DROP TABLE formateur');
        $this->addSql('DROP TABLE formation');
        $this->addSql('DROP TABLE utilisateur');
    }
}
